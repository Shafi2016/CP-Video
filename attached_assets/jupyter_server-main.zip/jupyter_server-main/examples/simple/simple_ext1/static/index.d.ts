declare function main(): void;
