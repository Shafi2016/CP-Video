Documentation for Developers
----------------------------

These pages target people writing Jupyter Web applications and server extensions, or people who need to dive deeper in Jupyter Server's REST API and configuration system.

.. toctree::
   :caption: Developers
   :maxdepth: 1
   :name: developers

   architecture
   dependency
   rest-api
   extensions
   savehooks
   contents
   websocket-protocols
   API Docs <../api/modules>
